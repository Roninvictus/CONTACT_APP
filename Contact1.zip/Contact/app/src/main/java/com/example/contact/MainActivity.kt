import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.contact.R

class ContactActivity : AppCompatActivity() {

    private lateinit var contactListView: ListView
    private lateinit var addContactButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        contactListView = findViewById(R.id.contact_list)
        addContactButton = findViewById(R.id.add_contact_button)

        // Set up the list view adapter
        val contacts = listOf(
            Contact("Victor", "victor@example.com"),
            Contact("Clary", "Clary@example.com"),
            Contact("Ertu", "Ertu@example.com")
        )
        val adapter = ArrayAdapter<Contact>(
            this,
            android.R.layout.simple_list_item_1,
            contacts
        )
        contactListView.adapter = adapter

        // Set up the add contact button
        addContactButton.setOnClickListener {
            // TODO: Handle the click event
        }
    }
}

data class Contact(val name: String, val email: String)
